package org.cts.dao;

public interface RegistrationCheckDao {
	public boolean registrationValidation( String uid);
}
