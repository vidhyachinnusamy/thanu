package org.cts.service;
import org.cts.bean.Registration;

public interface RegisterService {
public boolean CustomerRegistrationService(Registration r);
}
