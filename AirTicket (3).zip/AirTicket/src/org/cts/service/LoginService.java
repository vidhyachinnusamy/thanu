package org.cts.service;


import org.cts.bean.Login;

public interface LoginService {
public int loginService(Login l);
}
