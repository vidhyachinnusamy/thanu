package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.RegistrationCheckDao;
import org.cts.dao.RegistrationCheckDaoImpl;


@WebServlet("/DbCheck")
public class DbCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	RegistrationCheckDao dao=new RegistrationCheckDaoImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String msg="";
        String uid=request.getParameter("id");
        if(dao.registrationValidation(uid))
        {
               msg=msg+" user already exist.. ";
               
        }
        out.println(msg);

		
	}

}
